# README

In order to have a nice scores, you should run the following commands on your school machine.

First of all, you should just copy the file in this folder named `cs_todo.c` to your school machine, and then we will test this file stage by stage.

Once you find something wrong or tests failed, Please have a snapshot and save it to the local.

Finally, combine all the snapshots into a single file (like word file) and give it back to me, and I will give you the next actions(like submit or retest), thanks a lot.

### Before the stage

before we test our outcome file stage by stage, we should complile by using the following command in your school machine.

```bash
dcc cs_todo.c -o cs_todo
```

and then you can have a test of the execuable file by using the following command:

```bash
./cs_todo
```

and then just input `CTRL-D` is enough, then we will go into the truly test stage, and you should type the command line by line not just copy all the commands into the terminal at once.

## Stage 1

```bash
1091 autotest-stage 01_01 cs_todo
1091 autotest-stage 01_03 cs_todo
1091 autotest-stage 01_02 cs_todo
1091 autotest-stage 01_04 cs_todo
1091 autotest-stage 01_05 cs_todo
```

after test all the commands in the stage 1 I wanna you to save the code to the local by running the following commands

```bash
1091 style cs_todo.c
1091 autotest-stage 01 cs_todo
give dp1091 ass2_cs_todo cs_todo.c
```

That is all for the stage 1.

## stage 2

run the following commands to test:

```bash
1091 autotest-stage 02_01 cs_todo
1091 autotest-stage 02_02 cs_todo
1091 autotest-stage 02_03 cs_todo
```

after test all the commands in the stage 2 I wanna you to save the code to the local by running the following commands

```bash
1091 style cs_todo.c
1091 autotest-stage 02 cs_todo
give dp1091 ass2_cs_todo cs_todo.c
```

## stage 3

run the following commands to test:

```bash
1091 autotest-stage 03_01 cs_todo
1091 autotest-stage 03_02 cs_todo
1091 autotest-stage 03_03 cs_todo
```

However, the stage 3.4 is for testing the memory leak, the first command you should input to the terminal is 

```bash
1091 autotest-stage 03_04 cs_todo
```

but if it failed, Please input the following command(if not, just skip the following commands)

```bash
dcc cs_todo.c -o cs_todo --leak-check
```

and then test the examples in the stage 3.1 - 3.3, if anything failed again, please give the snapshots of them.

if not failed in the previous part, you can run the following command to test and save the codes

```bash
1091 style cs_todo.c
1091 autotest-stage 03 cs_todo
give dp1091 ass2_cs_todo cs_todo.c
```


## stage 4

Wow, finally we get to the stage 4 testing and commit, hope everything works well in the previous stages and it pass all the autotests. Just like what we've done before, just input the following commands, and it will verify the correctness of our program.

```bash
1091 autotest-stage 04_01 cs_todo
1091 autotest-stage 04_02 cs_todo
1091 autotest-stage 04_03 cs_todo
```

I promise the stage 4.1 and 4.2 is a tricky function. and you can do sumbit and final autotest for stage 4 running the following commands:

```bash
1091 style cs_todo.c
1091 autotest-stage 04 cs_todo
give dp1091 ass2_cs_todo cs_todo.c
```

Here, we finish all the testing and you can input the following commands for test all 4 the stages:

```bash
1091 autotest cs_todo
```

Thanks a lot.