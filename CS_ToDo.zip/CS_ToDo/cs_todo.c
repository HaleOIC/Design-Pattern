#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define INVALID_PRIORITY -1

#define MAX_TASK_LENGTH 200
#define MAX_CATEGORY_LENGTH 40
#define MAX_STRING_LENGTH 1024

// You *should* #define each command
#define COMMAND_ADD_TASK 'a'
#define COMMAND_PRINT_TASK 'p'
#define COMMAND_UPDATE_PRIORITY 'i'
#define COMMAND_COUNT_TASK 'n'
#define COMMAND_TASK_COMPLETION 'c'
#define COMMAND_PRINT_COM_TASK 'P'
#define COMMAND_EXPECTED_TIME 'e'
#define COMMAND_DELETE_TASK 'd'
#define COMMAND_FINISH_DAY 'f'
#define COMMAND_REPEAT_TASK 'r'
#define COMMAND_MATCH_TASK 'm'
#define COMMAND_DELETE_MATCHED '^'
#define COMMAND_SORT_TASKS 's'      

enum priority { LOW, MEDIUM, HIGH };

struct task {
    // self-defined new property of the task in the stage 3.3
    int repeatable;

    // original properties.
    char task_name[MAX_TASK_LENGTH];
    char category[MAX_CATEGORY_LENGTH];
    enum priority priority;

    struct task *next;


};

struct completed_task {
    struct task *task;
    int start_time;
    int finish_time;
    struct completed_task *next;
};

struct todo_list {
    struct task *tasks;
    struct completed_task *completed_tasks;
};

////////////////////////////////////////////////////////////////////////////////
///////////////////// YOUR FUNCTION PROTOTYPES GO HERE /////////////////////////
////////////////////////////////////////////////////////////////////////////////


void command_loop(struct todo_list *todo);

// self-defined helper control function to split up the program's logic.
void add_task(struct todo_list *todo);
void print_tasks(struct todo_list *todo);
void update_priority(struct todo_list *todo);
void count_tasks(struct todo_list *todo);
void task_completion(struct todo_list *todo);
void print_com_tasks(struct todo_list *todo);
void expected_time(struct todo_list *todo);
void delete_task(struct todo_list *todo);
void finish_day(struct todo_list *todo);
void repeat_task(struct todo_list *todo);
void match_task(struct todo_list *todo);
void delete_matched_tasks(struct todo_list *todo);
void sort_tasks(struct todo_list *todo);

void clear_todo(struct todo_list *todo);


// self-defined helper function
int match_pattern(char *pattern, char *target);

////////////////////////////////////////////////////////////////////////////////
//////////////////////// PROVIDED HELPER PROTOTYPES ////////////////////////////
////////////////////////////////////////////////////////////////////////////////

void parse_add_task_line(
    char buffer[MAX_STRING_LENGTH], char task_name[MAX_TASK_LENGTH],
    char task_category[MAX_CATEGORY_LENGTH], enum priority *prio
);
void parse_task_category_line(
    char buffer[MAX_STRING_LENGTH], char task_name[MAX_TASK_LENGTH],
    char task_category[MAX_CATEGORY_LENGTH]
);
void parse_complete_task_line(
    char buffer[MAX_STRING_LENGTH], char task_name[MAX_TASK_LENGTH],
    char task_category[MAX_CATEGORY_LENGTH], int *start_time, int *finish_time
);

enum priority string_to_priority(char priority[MAX_STRING_LENGTH]);
void remove_newline(char input[MAX_STRING_LENGTH]);
void trim_whitespace(char input[MAX_STRING_LENGTH]);
void print_one_task(int task_num, struct task *task);
void print_completed_task(struct completed_task *completed_task);

int task_compare(struct task *t1, struct task *t2);

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

int main(void) {
    printf("Welcome to CS ToDo!\n");
    // Stage 1.1
    // You should initialize the `todo` variable below. You will need
    // to use the malloc() function to allocate memory for it!
    struct todo_list *todo;
    
    // by using the malloc for allocating the memory
    todo = (struct todo_list*)malloc(sizeof(struct todo_list));

    // after allocate the dynamic memory we have a init.
    todo->tasks = NULL;
    todo->completed_tasks = NULL;
    
    command_loop(todo);

    // after finishing using the dynamic memory, we need to free it
    // in case the memory leak.
    free(todo);
    
    return 0;
}

/**
 * The central loop that executes commands until the program is completed.
 *
 * Parameters:
 *     todo - The todo list to execute commands on.
 *
 * Returns:
 *     Nothing
 */
void command_loop(struct todo_list *todo) {
    printf("Enter Command: ");
    char command;
    while (scanf(" %c", &command) == 1) {
        if (command == COMMAND_ADD_TASK) {
            // parse the todo_list pointer to the add_task function
            add_task(todo);
        } else if (command == COMMAND_PRINT_TASK) {
            // parse the todo_list pointer to the print_tasks function
            print_tasks(todo);
        } else if (command == COMMAND_UPDATE_PRIORITY) {
            // parse the todo_list pointer to the update_priority function
            update_priority(todo);
        } else if (command == COMMAND_COUNT_TASK) {
            // parse the todo_list pointer to the count_tasks function
            count_tasks(todo);
        } else if (command == COMMAND_TASK_COMPLETION) {
            // parse the todo_list pointer to the task_completion function
            task_completion(todo);
        } else if (command == COMMAND_PRINT_COM_TASK) {
            // parse the todo_list pointer to the print_com_tasks function
            print_com_tasks(todo);
        } else if (command == COMMAND_EXPECTED_TIME) {
            // parse the todo_list pointer to the expected_time function
            expected_time(todo);
        } else if (command == COMMAND_DELETE_TASK) {
            // parse the todo_list pointer to the delete_task function
            delete_task(todo);
        } else if (command == COMMAND_FINISH_DAY) {
            // parse the todo_list pointer to the finish_day function
            finish_day(todo);
        } else if (command == COMMAND_REPEAT_TASK) {
            // parse the todo_list pointer to the repeat_task function
            repeat_task(todo);
        } else if (command == COMMAND_MATCH_TASK) {
            // parse the todo_list pointer to the match_task function
            match_task(todo);
        } else if (command == COMMAND_DELETE_MATCHED) {
            // parse the todo_list pointer to the delete_matched_tasks function
            delete_matched_tasks(todo);
        } else if (command == COMMAND_SORT_TASKS) {
            // parse the todo_list pointer to the sort_tasks function
            sort_tasks(todo);
        }
        printf("Enter Command: ");
    }

    clear_todo(todo);

    // output format control
    printf("All done!\n");
}

////////////////////////////////////////////////////////////////////////////////
////////////////////////// YOUR HELPER FUNCTIONS ///////////////////////////////
////////////////////////////////////////////////////////////////////////////////

/**
 * clear the tasks and completed_tasks in the todo_list
 * 
 * paramter:
 *      todo - the operated linked lists
 * 
 * return:
 *      Nothing
 */
void clear_todo(struct todo_list *todo) {

    //before leave the program, we should give back the dynamic allocated memory
    struct task *ptr = todo->tasks, *next = NULL;
    while(ptr != NULL) {
        next = ptr->next;
        free(ptr);
        ptr = next;
    }

    struct completed_task *ptr_com = todo->completed_tasks, *next_com = NULL;
    while (ptr_com != NULL) {
        next_com = ptr_com->next;
        free(ptr_com->task);
        free(ptr_com);
        ptr_com = next_com;
    }
}



// You should add any helper functions you create here

/**
 * add one new task into the todo_list
 * 
 * parameter:
 *      todo - the todo list to add into 
 *
 * return:
 *      nothing.
 */
void add_task(struct todo_list *todo) {
    // Create a string to scan the entire command input into.
    char buffer[MAX_STRING_LENGTH];
    fgets(buffer, MAX_STRING_LENGTH, stdin);

    // Create variables for each part of the command being scanned in
    // (name of task, category of task and priority of task)
    char task_name[MAX_TASK_LENGTH];
    char task_category[MAX_CATEGORY_LENGTH];
    enum priority task_priority;
    parse_add_task_line(buffer, task_name, task_category, &task_priority);

    // in case that do not have the head task.
    struct task *head_tasks = todo->tasks;
    if (head_tasks == NULL) {    
        struct task* new_task = (struct task*)malloc(sizeof(struct task));
        new_task->repeatable = 0;
        strcpy(new_task->task_name, task_name);
        strcpy(new_task->category, task_category);
        new_task->priority = task_priority;
        new_task->next = NULL;
        // put the new task as the head.
        todo->tasks = new_task;
        return;
    }

    // check whether there exists the same task.
    struct task *ptr = head_tasks, *pre = NULL;
    while (ptr != NULL) {
        if (strcmp(ptr->task_name, task_name) == 0 
                && strcmp(ptr->category, task_category) == 0) {
            // find the same task just return back
            return;
        }
        pre = ptr;
        ptr = ptr->next;
    }

    // just add the new task to the tail of the linked lists.
    struct task* new_task = (struct task*)malloc(sizeof(struct task));
    new_task->repeatable = 0;
    strcpy(new_task->task_name, task_name);
    strcpy(new_task->category, task_category);
    new_task->priority = task_priority;    
    new_task->next = NULL;
    pre->next = new_task;
}

/**
 * print out the tasks in the linked list one by one
 * 
 * parameter:
 *     todo - the todo list to print out
 * 
 * return:
 *     nothing
 */
void print_tasks(struct todo_list *todo) {

    // control the output format
    printf("==== Your ToDo List ====\n");
    
    // generate the head of the todo_list s' tasks
    struct task *ptr = todo->tasks;
    int tot_num = 0;

    // enumarate all tasks one by one.
    while (ptr != NULL) {
        tot_num++;
        print_one_task(tot_num, ptr);
        ptr = ptr->next;
    }

    // in case the uncomplemented tasks is empty.
    if (tot_num == 0) {
        printf("All tasks completed, you smashed it!\n");
    }

    // control the output format
    printf("====   That's it!   ====\n");

}

/**
 * update priority in the todo_list especially in the tasks
 * 
 * parameters:
 *     todo - The todo list to execute commands on.
 * 
 * return:
 *     nothing.
 */
void update_priority(struct todo_list *todo) {
    // Fetch `[task] [category]` from stdin
    char buffer[MAX_STRING_LENGTH];
    fgets(buffer, MAX_STRING_LENGTH, stdin);

    // Create strings for `task`/`category` and populate them using the contents
    // of `buffer`
    char task[MAX_TASK_LENGTH];
    char category[MAX_CATEGORY_LENGTH];
    parse_task_category_line(buffer, task, category);

    // enumarate all tasks one by one
    struct task *ptr = todo->tasks;
    while (ptr != NULL) {
        if (strcmp(ptr->task_name, task) == 0 
                && strcmp(ptr->category, category) == 0) {
            // find the correct corresponding task
            if (ptr->priority == LOW) ptr->priority = MEDIUM;
            else if (ptr->priority == MEDIUM) ptr->priority = HIGH;
            else ptr->priority = LOW;
            return;
        }
        ptr = ptr->next;
    }

    // can not find the corresponding one.
    printf("Could not find task '%s' in category '%s'.\n", task, category);
}


/**
 * count the total number of tasks in the todo list
 * 
 * parameter:
 *      todo - the todo list to count.
 * 
 * return:
 *      nothing
 */
void count_tasks(struct todo_list *todo) {

    // enumarate all tasks one by one
    struct task *ptr = todo->tasks;
    int tot_num = 0;
    while (ptr != NULL) {
        tot_num++;
        ptr = ptr->next;
    }

    // print out the counting value.
    printf("There are %d items on your list!\n", tot_num);

}

/**
 * The goal is to search for a task in the tasks list that 
 * corresponds to the [task] and [category] entered with the c command. 
 * This task should then be removed from the tasks list and added to 
 * the head of the completed_tasks list,
 *
 * paramter:
 *      todo - the todo list to operate 
 * 
 * return:
 *      nothing
 */
void task_completion(struct todo_list *todo) {
    // Fetch `[task] [category] [start_time] [finish_time]` from stdin
    char buffer[MAX_STRING_LENGTH];
    fgets(buffer, MAX_STRING_LENGTH, stdin);

    // Create strings for `task`/`category` and ints for times, then populate
    // them using the contents of `buffer`.
    char task[MAX_TASK_LENGTH];
    char category[MAX_CATEGORY_LENGTH];
    int start_time;
    int finish_time;
    parse_complete_task_line(buffer, task, category, &start_time, &finish_time);

    // enumerate all tasks one by one for searching the task
    struct task *ptr = todo->tasks, *pre = NULL;

    while (ptr != NULL) {
        if (strcmp(ptr->task_name, task) == 0 
                && strcmp(ptr->category, category) == 0) {
            break;
        }
        pre = ptr;
        ptr = ptr->next;
    }

    // in case the task can not be found in the todo_list
    if (ptr == NULL) {
        printf("Could not find task '%s' in category '%s'.\n", task, category);
        return;
    }

    // in case the start_time equals to -1
    if (start_time == -1) {
        struct completed_task *ptr_com = todo->completed_tasks;
        int value = 0;
        while (ptr_com != NULL) {
            value = (value > ptr_com->finish_time) ? value : ptr_com->finish_time;
            ptr_com = ptr_com->next;
        }
        start_time = value;
    }

    // add the completed task into the todo_list completed_tasks
    // by using the malloc command
    struct completed_task *new_com_task = 
                        (struct completed_task*)malloc(sizeof(struct completed_task));
    // setup relative properies.
    new_com_task->next = todo->completed_tasks;
    new_com_task->task = ptr;
    new_com_task->start_time = start_time;
    new_com_task->finish_time = finish_time;
    todo->completed_tasks = new_com_task;
    
    // delete the task from the todo_list tasks
    if (pre == NULL) {
        todo->tasks = ptr->next;
    } else {
        pre->next = ptr->next;
    }
    ptr->next = NULL;
}

/**
 * print out the completed tasks in the todo_list.
 * 
 * parameter:
 *      todo - the todo list to print out
 * 
 * return:
 *      nothing
 */
void print_com_tasks(struct todo_list *todo) {
     // control the output format
    printf("==== Completed Tasks ====\n");
    
    // generate the head of the todo_list s' tasks
    struct completed_task *ptr = todo->completed_tasks;
    int tot_num = 0;

    // enumarate all completed tasks one by one.
    while (ptr != NULL) {
        tot_num++;
        print_completed_task(ptr);
        ptr = ptr->next;
    }

    // in case the uncomplemented tasks is empty.
    if (tot_num == 0) {
        printf("No tasks have been completed today!\n");
    }

    // control the output format
    printf("=========================\n");
}

/**
 * calculate the expected time for the incomplemte task 
 * one by one and print it out
 * 
 * parameter:
 *      todo - the operating todo_list
 * 
 * return:
 *      nothing
 */
void expected_time(struct todo_list *todo) {

    // control the output format
    printf("Expected completion time for remaining tasks:\n\n");


    // enumerate each task one by one.
    struct task *ptr = todo->tasks;
    int num = 0;
    while (ptr != NULL) {
        num++;
        int tot_time = 0, tot_num = 0;
        struct completed_task *each = todo->completed_tasks;
        while (each != NULL) {
            // each the same strategy to calculate as the new one.
            if (strcmp(ptr->category, each->task->category) == 0) {
                tot_num += 1;
                tot_time += each->finish_time - each->start_time;
            }
            // switch to the next com_task.
            each = each->next;
        }
        
        // control the output format.
        print_one_task(num, ptr);
        printf("Expected completion time: ");
        if (tot_num == 0) {
            printf("100 minutes\n\n");
        } else {
            printf("%d minutes\n\n", tot_time / tot_num);
        }

        // go to the next unfinished task.
        ptr = ptr->next;
    }
} 

/**
 * delete the corresponding task in the todo list
 * 
 * parameter:
 *      todo - the operated todo_list
 * 
 * return:
 *      Nothing
 */
void delete_task(struct todo_list *todo) {
    // Fetch `[task] [category]` from stdin
    char buffer[MAX_STRING_LENGTH];
    fgets(buffer, MAX_STRING_LENGTH, stdin);

    // Create strings for `task`/`category` and populate them using the contents
    // of `buffer`
    char task[MAX_TASK_LENGTH];
    char category[MAX_CATEGORY_LENGTH];
    parse_task_category_line(buffer, task, category);

    // enumerate the task one by one
    struct task* ptr = todo->tasks, *pre = NULL;
    while (ptr != NULL) {
        if (strcmp(ptr->task_name, task) == 0 
                && strcmp(ptr->category, category) == 0) {
            break;
        }
        pre = ptr;
        ptr = ptr->next;
    }

    // in case the ptr is NULL
    if (ptr == NULL) {
        printf("Could not find task '%s' in category '%s'.\n", task, category);
        return;
    }


    // just delete the node and free the dynamic allocated memory
    if (pre == NULL) {
        todo->tasks = ptr->next;
    } else {
        pre->next = ptr->next;        
    }
    free(ptr);
}


/**
 * remove all the tasks that we have completed
 *
 * parameter:
 *      todo - the operated todo_list 
 * 
 * return:
 *      Nothing.
 */
void finish_day(struct todo_list *todo) {
    //enumerate each completed task one by one.
    struct completed_task *ptr = todo->completed_tasks, *next = NULL;
    todo->completed_tasks = NULL;
    while(ptr != NULL) {
        next = ptr->next;

        if (ptr->task->repeatable) {
            // make the repeatable task to the tail of the todo_list.
            struct task *each = todo->tasks, *pre = NULL;
            while (each != NULL) {
                pre = each;
                each = each->next;
            }
            // in case the todo->tasks is empty.
            if (pre == NULL) {
                todo->tasks = ptr->task;
            } else {
                pre->next = ptr->task;
            }
        } else {
            // freeup the task.
            free(ptr->task);
        }
        // free up the completed task node.
        free(ptr);
        ptr = next;
    }
}

/**
 * make target task as the repeatable or remove the repeating.
 * 
 * parameter:
 *     todo - the operated todo_list
 * 
 * return:
 *      Nothing.
 */
void repeat_task(struct todo_list *todo) {
    // Fetch `[task] [category]` from stdin
    char buffer[MAX_STRING_LENGTH];
    fgets(buffer, MAX_STRING_LENGTH, stdin);

    // Create strings for `task`/`category` and populate them using the contents
    // of `buffer`
    char task[MAX_TASK_LENGTH];
    char category[MAX_CATEGORY_LENGTH];
    parse_task_category_line(buffer, task, category);

    // enumerate the task one by one
    struct task *ptr = todo->tasks;
    while (ptr != NULL) {
        if (strcmp(ptr->task_name, task) == 0 
                && strcmp(ptr->category, category) == 0) {
            break;
        }
        ptr = ptr->next;
    }

    // in case the ptr is NULL
    if (ptr == NULL) {
        printf("Could not find task '%s' in category '%s'.\n", task, category);
        return;
    }

    // adverse the repeatable property.
    ptr->repeatable = 1 - ptr->repeatable;
}

/**
 * match task names with a given pattern
 * 
 * paramter:    
 *      todo - the operated todo_list
 * 
 * return:
 *      Nothing
 */
void match_task(struct todo_list *todo) {

    char pattern[MAX_STRING_LENGTH];
    fgets(pattern, MAX_STRING_LENGTH, stdin);

    trim_whitespace(pattern);

    printf("Tasks matching pattern '%s':\n", pattern);
    // enumerate each task one by one 
    struct task *ptr = todo->tasks;
    int tot_num = 0;
    while (ptr != NULL) {
        if (match_pattern(pattern, ptr->task_name) == 1) {
            tot_num++;
            print_one_task(tot_num, ptr);
        }
        ptr = ptr->next;
    }
}  

/**
 * match task names with a given pattern and delete them
 * 
 * paramter:    
 *      todo - the operated todo_list
 * 
 * return:
 *      Nothing
 */
void delete_matched_tasks(struct todo_list *todo) {
    char pattern[MAX_STRING_LENGTH];
    fgets(pattern, MAX_STRING_LENGTH, stdin);

    trim_whitespace(pattern);

    // enumerate each task one by one 
    struct task *ptr = todo->tasks, *pre = NULL;
    while (ptr != NULL) {
        if (match_pattern(pattern, ptr->task_name) == -1) {
            pre = ptr;
            ptr = ptr->next;
            continue;
        }
        // in the case that the ptr should be deleted.
        if (pre == NULL) {
            todo->tasks = ptr->next;
        } else {
            pre->next = ptr->next;
        }
        struct task *tmp = ptr->next;
        free(ptr);
        ptr = tmp;
    }
}


/**
 * sort the tasks in the rules.
 * 
 * paramter:    
 *      todo - the operated todo_list
 * 
 * return:
 *      Nothing
 */
void sort_tasks(struct todo_list *todo) {
    
    struct task *head = todo->tasks;
    // in case the head is null and then we will access to the null->next.
    if (head == NULL) {
        return;
    }
    // right now task to insert.
    struct task *cur = todo->tasks->next;
    head->next = NULL;
    while(cur != NULL) {
        struct task *ptr = head, *pre = NULL, *cur_next = cur->next;
        // find the right position for the inserted task.
        while (ptr != NULL) {
            if (task_compare(cur, ptr) < 0) {
                // means the cur task is before the ptr
                break;    
            } 
            pre = ptr;
            ptr = ptr->next;
        }
        // insert the cur into the right position.
        if (pre == NULL) {
            head = cur; 
        } else {
            pre->next = cur;
        }
        cur->next = ptr;
        cur = cur_next;
    }
    //set the right order of task
    todo->tasks = head;
}

/**
 * make a match between pattern and target string
 * 
 * parameter:
 *      pattern - the matching pattern
 *      target - the matched target
 * 
 * return:
 *      the outcome of the match
 *      1 - success
 *      -1 - failed
 */
int match_pattern(char *pattern, char *target) {
    // the main thought is just decrease the pattern string from left and right
    // to make the rest string as the single match character * or nothing
    int left_pa = 0, left_ta = 0;
    while(left_pa < strlen(pattern) && left_ta < strlen(target)) {
        if (pattern[left_pa] == '*') {
            break;
        } else if (pattern[left_pa] == '?') {
            left_pa++;
        } else if (pattern[left_pa] == target[left_ta]) {
            left_pa++;
        } else if (pattern[left_pa] == '[') {
            int pos = left_pa + 1, flag = 0;
            while(pattern[pos] != ']') {
                if (pattern[pos] == target[left_ta]) {
                    flag = 1;
                }
                pos = pos + 1;
            }
            if (!flag) {
                return -1;
            }
            left_pa = pos + 1;
        } else {
            return -1;
        }
        // consider the next character in the target string.
        left_ta++;
    }
    // finish the match pattern
    if (left_pa == strlen(pattern)) {
        if (left_ta == strlen(target)) return 1;
        else return -1;
    }

    // the same what we do from the right.
    int right_pa = strlen(pattern) - 1, right_ta = strlen(target) - 1;
    while(right_pa >= 0 && right_ta >= 0) {
        if (pattern[right_pa] == target[right_ta]) {
            right_pa--;
        } else if (pattern[right_pa] == '?') {
            right_pa--;
        } else if (pattern[right_pa] == ']') {
            int pos = right_pa - 1, flag = 0;
            while(pattern[pos] != '[') {
                if (pattern[pos] == target[right_ta]) {
                    flag = 1;
                }
                pos = pos - 1;
            }
            if (!flag) {
                return -1;
            }
            right_pa = pos - 1;
        } else if (pattern[right_pa] == '*') {
            break;
        } else {
            return -1;
        }
        right_ta--;
    }
    // encounter the final case.
    if (left_ta - 1 <= right_ta) {
        return 1;
    } else {
        return -1;
    }
}
////////////////////////////////////////////////////////////////////////////////
/////////////////////// PROVIDED HELPER FUNCTIONS //////////////////////////////
////////////////////////////////////////////////////////////////////////////////

/**
 * Helper Function
 * You DO NOT NEED TO UNDERSTAND THIS FUNCTION, and will not need to change it.
 *
 * Given a raw string in the format: [string1] [string2] [enum priority]
 * This function will extract the relevant values into the given variables.
 * The function will also remove any newline characters.
 *
 * For example, if given: "finish_assignment_2 assignment2 high"
 * The function will copy the string:
 *     "finish_assignment_2" into the `task_name` array
 * Then copy the string:
 *     "assignment2" into the `task_category` array
 * And finally, copy over the enum:
 *     "high" into the memory that `prio` is pointing at.
 *
 * Parameters:
 *     buffer        - A null terminated string in the following format
 *                     [string1] [string2] [enum priority]
 *     task_name     - A character array for the [string1] to be copied into
 *     task_category - A character array for the [string2] to be copied into
 *     prio          - A pointer to where [enum priority] should be stored
 *
 * Returns:
 *     None
 */
void parse_add_task_line(
    char buffer[MAX_STRING_LENGTH],
    char task_name[MAX_TASK_LENGTH],
    char task_category[MAX_CATEGORY_LENGTH],
    enum priority *prio
) {
    remove_newline(buffer);

    // Extract value 1 as string
    char *name_str = strtok(buffer, " ");
    if (name_str != NULL) {
        strcpy(task_name, name_str);
    }

    // Extract value 2 as string
    char *category_str = strtok(NULL, " ");
    if (category_str != NULL) {
        strcpy(task_category, category_str);
    }
    
    // Extract value 3 as string
    char *prio_str = strtok(NULL, " ");
    if (prio_str != NULL) {
        *prio = string_to_priority(prio_str);
    }

    if (
        name_str == NULL ||
        category_str == NULL ||
        prio_str == NULL ||
        *prio == INVALID_PRIORITY
    ) {
        // If any of these are null, there were not enough words.
        printf("Could not properly parse line: '%s'.\n", buffer);
    }
}

/*
 * Helper Function
 * You DO NOT NEED TO UNDERSTAND THIS FUNCTION, and will not need to change it.
 *
 * See `parse_add_task_line` for explanation - This function is very similar,
 * with only the exclusion of an `enum priority`.
 */
void parse_task_category_line(
    char buffer[MAX_STRING_LENGTH],
    char task_name[MAX_TASK_LENGTH],
    char task_category[MAX_CATEGORY_LENGTH]
) {
    remove_newline(buffer);

    // Extract value 1 as string
    char *name_str = strtok(buffer, " ");
    if (name_str != NULL) {
        strcpy(task_name, name_str);
    }

    // Extract value 2 as string
    char *category_str = strtok(NULL, " ");
    if (category_str != NULL) {
        strcpy(task_category, category_str);
    }

    if (name_str == NULL || category_str == NULL) {
        // If any of these are null, there were not enough words.
        printf("Could not properly parse line: '%s'.\n", buffer);
    }
}

/*
 * Helper Function
 * You DO NOT NEED TO UNDERSTAND THIS FUNCTION, and will not need to change it.
 *
 * See `parse_add_task_line` for explanation - This function is very similar,
 * with only the exclusion of an `enum priority` and addition of start/end times
 */
void parse_complete_task_line(
    char buffer[MAX_STRING_LENGTH],
    char task_name[MAX_TASK_LENGTH],
    char task_category[MAX_CATEGORY_LENGTH],
    int *start_time,
    int *finish_time
) {
    remove_newline(buffer);

    // Extract value 1 as string
    char *name_str = strtok(buffer, " ");
    if (name_str != NULL) {
        strcpy(task_name, name_str);
    }

    // Extract value 2 as string
    char *category_str = strtok(NULL, " ");
    if (category_str != NULL) {
        strcpy(task_category, category_str);
    }
    
    // Extract value 2 as string
    char *start_str = strtok(NULL, " ");
    if (start_str != NULL) {
        *start_time = atoi(start_str);
    }
    
    // Extract value 2 as string
    char *finish_str = strtok(NULL, " ");
    if (finish_str != NULL) {
        *finish_time = atoi(finish_str);
    }

    if (
        name_str == NULL ||
        category_str == NULL ||
        start_str == NULL ||
        finish_str == NULL
    ) {
        // If any of these are null, there were not enough words.
        printf("Could not properly parse line: '%s'.\n", buffer);
    }
}

/**
 * Helper Function
 * You should not need to change this function.
 *
 * Given a raw string, will return the corresponding `enum priority`,
 * or INVALID_PRIORITY if the string doesn't correspond with the enums.
 *
 * Parameters:
 *     priority - string representing the corresponding `enum priority` value
 * Returns:
 *     enum priority
 */
enum priority string_to_priority(char priority[MAX_STRING_LENGTH]) {
    if (strcmp(priority, "low") == 0) {
        return LOW;
    } else if (strcmp(priority, "medium") == 0) {
        return MEDIUM;
    } else if (strcmp(priority, "high") == 0) {
        return HIGH;
    }

    return INVALID_PRIORITY;
}

/**
 * Helper Function
 * You should not need to change this function.
 *
 * Given an priority and a character array, fills the array with the
 * corresponding string version of the priority.
 *
 * Parameters:
 *     prio - the `enum priority` to convert from
 *     out  - the array to populate with the string version of `prio`.
 * Returns:
 *     Nothing
 */
void priority_to_string(enum priority prio, char out[MAX_STRING_LENGTH]) {
    if (prio == LOW) {
        strcpy(out, "LOW");
    } else if (prio == MEDIUM) {
        strcpy(out, "MEDIUM");
    } else if (prio == HIGH) {
        strcpy(out, "HIGH");
    } else {
        strcpy(out, "Provided priority was invalid");
    }
}

/*
 * Helper Function
 * You should not need to change this function.
 *
 * Given a raw string will remove and first newline it sees.
 * The newline character wil be replaced with a null terminator ('\0')
 *
 * Parameters:
 *     input - The string to remove the newline from
 *
 * Returns:
 *     Nothing
 */
void remove_newline(char input[MAX_STRING_LENGTH]) {
    // Find the newline or end of string
    int index = 0;
    while (input[index] != '\n' && input[index] != '\0') {
        index++;
    }
    // Goto the last position in the array and replace with '\0'
    // Note: will have no effect if already at null terminator
    input[index] = '\0';
}

/*
 * Helper Function
 * You likely do not need to change this function.
 *
 * Given a raw string, will remove any whitespace that appears at the start or
 * end of said string.
 *
 * Parameters:
 *     input - The string to trim whitespace from
 *
 * Returns:
 *     Nothing
 */
void trim_whitespace(char input[MAX_STRING_LENGTH]) {
    remove_newline(input);
    
    int lower;
    for (lower = 0; input[lower] == ' '; ++lower);
    
    int upper;
    for (upper = strlen(input) - 1; input[upper] == ' '; --upper);
    
    for (int base = lower; base <= upper; ++base) {
        input[base - lower] = input[base];
    }

    input[upper - lower + 1] = '\0';
}

/**
 * Helper Function
 * You SHOULD NOT change this function.
 *
 * Given a task, prints it out in the format specified in the assignment.
 *
 * Parameters:
 *     task_num - The position of the task within a todo list
 *     task     - The task in question to print
 *
 * Returns:
 *     Nothing
 */
void print_one_task(int task_num, struct task *task) {
    char prio_str[MAX_STRING_LENGTH];
    priority_to_string(task->priority, prio_str);

    printf(
        "  %02d. %-30.30s [ %s ] %s\n",
        task_num, task->task_name, task->category, prio_str
    );

    int i = 30;
    while (i < strlen(task->task_name)) {
        printf("      %.30s\n", task->task_name + i);
        i += 30;
    }
}

/**
 * Helper Function
 * You SHOULD NOT change this function.
 *
 * Given a completed task, prints it out in the format specified in the
 * assignment.
 *
 * Parameters:
 *     completed_task - The task in question to print
 *
 * Returns:
 *     Nothing
 */
void print_completed_task(struct completed_task *completed_task) {
    int start_hour = completed_task->start_time / 60;
    int start_minute = completed_task->start_time % 60;
    int finish_hour = completed_task->finish_time / 60;
    int finish_minute = completed_task->finish_time % 60;
    
    printf(
        "  %02d:%02d-%02d:%02d | %-30.30s [ %s ]\n",
        start_hour, start_minute, finish_hour, finish_minute,
        completed_task->task->task_name, completed_task->task->category
    );

    int i = 30;
    while (i < strlen(completed_task->task->task_name)) {
        printf("      %.30s\n", (completed_task->task->task_name + i));
        i += 30;
    }
}

/**
 * Compares two tasks by precedence of category -> priority -> name and returns
 * an integer referring to their relative ordering
 * 
 * Parameters:
 *     t1 - The first task to compare
 *     t2 - The second task to compare
 *
 * Returns:
 *     a negative integer if t1 belongs before t2
 *     a positive integer if t1 belongs after t2
 *     0 if the tasks are identical (This should never happen in your program)
 */
int task_compare(struct task *t1, struct task *t2) {
    int category_diff = strcmp(t1->category, t2->category);
    if (category_diff != 0) {
        return category_diff;
    }
    
    int priority_diff = t2->priority - t1->priority;
    if (priority_diff != 0) {
        return priority_diff;
    }
    
    return strcmp(t1->task_name, t2->task_name);
}